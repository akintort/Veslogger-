# VESLogger Android App

VESLogger is an Android application for Vertical Electrical Sounding (VES) measurements and data logging.

## Features

- Project management for VES surveys
- Data entry and measurement logging
- Graph visualization of resistivity data
- Export functionality (CSV, PDF)
- GPS location tracking
- Data quality warnings

## Building the APK

This project uses GitHub Actions to automatically build APK files.

### Automatic Build (Recommended)

1. Fork this repository
2. Go to Actions tab in your forked repository
3. Click "Build Android APK" workflow
4. Click "Run workflow" button
5. Wait for the build to complete
6. Download the APK from the artifacts section

### Manual Build

If you have Android Studio and proper SDK setup:

```bash
./gradlew assembleDebug
./gradlew assembleRelease
```

## Installation

1. Download the APK from the GitHub Actions artifacts
2. Enable "Unknown sources" in your Android device settings
3. Install the APK file

## Requirements

- Android 5.0 (API level 21) or higher
- GPS capability for location features
- Storage permission for data export

## License

This project is open source.
