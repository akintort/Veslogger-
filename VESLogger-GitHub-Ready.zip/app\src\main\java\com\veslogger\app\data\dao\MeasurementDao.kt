package com.veslogger.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.veslogger.app.data.model.Measurement

@Dao
interface MeasurementDao {
    
    @Query("SELECT * FROM measurements WHERE projectId = :projectId ORDER BY sequenceNumber ASC")
    fun getMeasurementsByProject(projectId: String): LiveData<List<Measurement>>
    
    @Query("SELECT * FROM measurements WHERE projectId = :projectId ORDER BY sequenceNumber ASC")
    suspend fun getMeasurementsByProjectSync(projectId: String): List<Measurement>
    
    @Query("SELECT * FROM measurements WHERE id = :measurementId")
    suspend fun getMeasurementById(measurementId: String): Measurement?
    
    @Query("SELECT COUNT(*) FROM measurements WHERE projectId = :projectId")
    suspend fun getMeasurementCount(projectId: String): Int
    
    @Query("SELECT COUNT(*) FROM measurements WHERE projectId = :projectId AND isCompleted = 1")
    suspend fun getCompletedMeasurementCount(projectId: String): Int
    
    @Query("SELECT * FROM measurements WHERE projectId = :projectId AND isCompleted = 0 ORDER BY sequenceNumber ASC LIMIT 1")
    suspend fun getNextIncompleteMeasurement(projectId: String): Measurement?
    
    @Query("SELECT MAX(sequenceNumber) FROM measurements WHERE projectId = :projectId")
    suspend fun getMaxSequenceNumber(projectId: String): Int?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurement(measurement: Measurement): Long
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurements(measurements: List<Measurement>)
    
    @Update
    suspend fun updateMeasurement(measurement: Measurement)
    
    @Delete
    suspend fun deleteMeasurement(measurement: Measurement)
    
    @Query("DELETE FROM measurements WHERE id = :measurementId")
    suspend fun deleteMeasurementById(measurementId: String)
    
    @Query("DELETE FROM measurements WHERE projectId = :projectId")
    suspend fun deleteAllMeasurementsForProject(projectId: String)
    
    @Query("UPDATE measurements SET resistance = :resistance, isCompleted = :isCompleted, modifiedAt = :timestamp WHERE id = :measurementId")
    suspend fun updateMeasurementResistance(
        measurementId: String, 
        resistance: Double, 
        isCompleted: Boolean = true, 
        timestamp: Long = System.currentTimeMillis()
    )
    
    @Query("SELECT * FROM measurements WHERE projectId = :projectId AND resistance IS NOT NULL AND resistance > 0 ORDER BY ab2 ASC")
    suspend fun getValidMeasurementsForGraph(projectId: String): List<Measurement>
}





