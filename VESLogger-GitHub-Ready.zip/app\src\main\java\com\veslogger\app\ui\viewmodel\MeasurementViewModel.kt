package com.veslogger.app.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.veslogger.app.data.model.Measurement
import com.veslogger.app.data.model.Project
import com.veslogger.app.data.repository.DataQualityResult
import com.veslogger.app.data.repository.VESRepository
import kotlinx.coroutines.launch

class MeasurementViewModel(
    private val repository: VESRepository
) : ViewModel() {
    
    private val _projectId = MutableLiveData<String>()
    val projectId: String get() = _projectId.value ?: ""
    
    val project: LiveData<Project?> = _projectId.switchMap { id ->
        repository.getProjectByIdLiveData(id)
    }
    
    val measurements: LiveData<List<Measurement>> = _projectId.switchMap { id ->
        repository.getMeasurementsByProject(id)
    }
    
    private val _nextIncompleteMeasurement = MutableLiveData<Measurement?>()
    val nextIncompleteMeasurement: LiveData<Measurement?> = _nextIncompleteMeasurement
    
    private val _measurementCounts = MutableLiveData<Pair<Int, Int>>()
    val measurementCounts: LiveData<Pair<Int, Int>> = _measurementCounts
    
    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading
    
    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error
    
    fun setProjectId(projectId: String) {
        _projectId.value = projectId
        loadMeasurementCounts()
        loadNextIncompleteMeasurement()
    }
    
    suspend fun saveMeasurement(measurement: Measurement) {
        try {
            _isLoading.value = true
            repository.updateMeasurement(measurement)
            repository.updateProjectModifiedTime(projectId)
            loadMeasurementCounts()
        } catch (e: Exception) {
            _error.value = "Ölçüm kaydedilemedi: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun addNewMeasurement(measurement: Measurement) {
        try {
            _isLoading.value = true
            repository.insertMeasurement(measurement)
            repository.updateProjectModifiedTime(projectId)
            loadMeasurementCounts()
        } catch (e: Exception) {
            _error.value = "Ölçüm eklenemedi: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun deleteMeasurement(measurement: Measurement) {
        try {
            _isLoading.value = true
            repository.deleteMeasurement(measurement)
            repository.updateProjectModifiedTime(projectId)
            loadMeasurementCounts()
        } catch (e: Exception) {
            _error.value = "Ölçüm silinemedi: ${e.message}"
        } finally {
            _isLoading.value = false
        }
    }
    
    suspend fun getNextSequenceNumber(): Int {
        return try {
            val measurements = repository.getMeasurementsByProjectSync(projectId)
            (measurements.maxOfOrNull { it.sequenceNumber } ?: 0) + 1
        } catch (e: Exception) {
            1
        }
    }
    
    suspend fun checkDataQuality(measurement: Measurement): DataQualityResult {
        return repository.checkDataQuality(projectId, measurement)
    }
    
    fun loadNextIncompleteMeasurement() {
        viewModelScope.launch {
            try {
                val nextMeasurement = repository.getNextIncompleteMeasurement(projectId)
                _nextIncompleteMeasurement.value = nextMeasurement
            } catch (e: Exception) {
                _error.value = "Sonraki ölçüm yüklenemedi: ${e.message}"
            }
        }
    }
    
    private fun loadMeasurementCounts() {
        viewModelScope.launch {
            try {
                val total = repository.getMeasurementCount(projectId)
                val completed = repository.getCompletedMeasurementCount(projectId)
                _measurementCounts.value = Pair(total, completed)
            } catch (e: Exception) {
                _error.value = "İstatistikler yüklenemedi: ${e.message}"
            }
        }
    }
    
    suspend fun getValidMeasurementsForGraph(): List<Measurement> {
        return repository.getValidMeasurementsForGraph(projectId)
    }
    
    suspend fun exportMeasurements(): List<Measurement> {
        return repository.getMeasurementsByProjectSync(projectId)
    }
    
    fun clearError() {
        _error.value = null
    }
}





