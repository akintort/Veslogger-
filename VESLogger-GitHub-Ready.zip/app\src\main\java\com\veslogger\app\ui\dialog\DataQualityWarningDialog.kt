package com.veslogger.app.ui.dialog

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.veslogger.app.R

class DataQualityWarningDialog : DialogFragment() {
    
    private var onDecisionMade: ((Boolean) -> Unit)? = null
    private var ratio: Double = 1.0
    
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        ratio = arguments?.getDouble(ARG_RATIO) ?: 1.0
        
        val ratioText = if (ratio >= 1.0) {
            String.format("%.1f", ratio)
        } else {
            String.format("1/%.1f", 1.0 / ratio)
        }
        
        return AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.data_quality_warning))
            .setMessage(getString(R.string.unusual_value_message, ratioText))
            .setIcon(R.drawable.ic_warning)
            .setPositiveButton(getString(R.string.save_anyway)) { _, _ ->
                onDecisionMade?.invoke(true)
            }
            .setNegativeButton(getString(R.string.check_measurement)) { _, _ ->
                onDecisionMade?.invoke(false)
            }
            .setCancelable(true)
            .create()
    }
    
    companion object {
        private const val ARG_RATIO = "ratio"
        
        fun newInstance(ratio: Double, onDecisionMade: (Boolean) -> Unit): DataQualityWarningDialog {
            return DataQualityWarningDialog().apply {
                arguments = Bundle().apply {
                    putDouble(ARG_RATIO, ratio)
                }
                this.onDecisionMade = onDecisionMade
            }
        }
    }
}





