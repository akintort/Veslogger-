package com.veslogger.app.data.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize
import java.util.*
import kotlin.math.*

@Parcelize
@Entity(
    tableName = "measurements",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Measurement(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val sequenceNumber: Int,
    val ab2: Double, // AB/2 electrode spacing in meters
    val mn2: Double, // MN/2 electrode spacing in meters
    val resistance: Double? = null, // Measured resistance in Ohms
    val kFactor: Double = 0.0, // Geometric factor K
    val apparentResistivity: Double = 0.0, // Calculated apparent resistivity in Ohm.m
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val modifiedAt: Long = System.currentTimeMillis(),
    val notes: String = ""
) : Parcelable {
    
    /**
     * Calculate geometric factor K
     * K = π * [((AB/2)² - (MN/2)²)/(2 * MN/2)]
     */
    fun calculateKFactor(): Double {
        if (mn2 <= 0) return 0.0
        return PI * ((ab2.pow(2) - mn2.pow(2)) / (2 * mn2))
    }
    
    /**
     * Calculate apparent resistivity
     * ρa = K * R
     */
    fun calculateApparentResistivity(): Double {
        return if (resistance != null) {
            calculateKFactor() * resistance
        } else {
            0.0
        }
    }
    
    /**
     * Create a copy with calculated values
     */
    fun withCalculatedValues(): Measurement {
        val k = calculateKFactor()
        val rho = if (resistance != null) k * resistance else 0.0
        return copy(
            kFactor = k,
            apparentResistivity = rho,
            isCompleted = resistance != null,
            modifiedAt = System.currentTimeMillis()
        )
    }
    
    /**
     * Check if this measurement has valid data
     */
    fun isValid(): Boolean {
        return ab2 > 0 && mn2 > 0 && ab2 > mn2 && resistance != null && resistance > 0
    }
    
    companion object {
        /**
         * Create a new measurement with auto-calculated sequence number
         */
        fun create(
            projectId: String,
            sequenceNumber: Int,
            ab2: Double,
            mn2: Double,
            resistance: Double? = null
        ): Measurement {
            val measurement = Measurement(
                projectId = projectId,
                sequenceNumber = sequenceNumber,
                ab2 = ab2,
                mn2 = mn2,
                resistance = resistance
            )
            return measurement.withCalculatedValues()
        }
    }
}





