package com.veslogger.app.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.veslogger.app.data.model.Project

@Dao
interface ProjectDao {
    
    @Query("SELECT * FROM projects ORDER BY modifiedAt DESC")
    fun getAllProjects(): LiveData<List<Project>>
    
    @Query("SELECT * FROM projects WHERE id = :projectId")
    suspend fun getProjectById(projectId: String): Project?
    
    @Query("SELECT * FROM projects WHERE id = :projectId")
    fun getProjectByIdLiveData(projectId: String): LiveData<Project?>
    
    @Query("SELECT COUNT(*) FROM projects")
    suspend fun getProjectCount(): Int
    
    @Query("SELECT * FROM projects WHERE name LIKE :searchQuery ORDER BY modifiedAt DESC")
    fun searchProjects(searchQuery: String): LiveData<List<Project>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project): Long
    
    @Update
    suspend fun updateProject(project: Project)
    
    @Delete
    suspend fun deleteProject(project: Project)
    
    @Query("DELETE FROM projects WHERE id = :projectId")
    suspend fun deleteProjectById(projectId: String)
    
    @Query("UPDATE projects SET modifiedAt = :timestamp WHERE id = :projectId")
    suspend fun updateModifiedTime(projectId: String, timestamp: Long = System.currentTimeMillis())
    
    @Query("UPDATE projects SET isCompleted = :isCompleted WHERE id = :projectId")
    suspend fun updateProjectCompletion(projectId: String, isCompleted: Boolean)
}





