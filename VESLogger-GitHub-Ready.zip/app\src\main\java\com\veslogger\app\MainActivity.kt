package com.veslogger.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.veslogger.app.databinding.ActivityMainBinding
import com.veslogger.app.ui.ProjectSetupActivity

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupClickListeners()
    }
    
    private fun setupClickListeners() {
        binding.newProjectCard.setOnClickListener {
            startActivity(Intent(this, ProjectSetupActivity::class.java))
        }
        
        // Temporarily disable other features
        binding.loadProjectCard.setOnClickListener {
            // TODO: Implement project loading
        }
        
        binding.settingsCard.setOnClickListener {
            // TODO: Implement settings
        }
    }
}





