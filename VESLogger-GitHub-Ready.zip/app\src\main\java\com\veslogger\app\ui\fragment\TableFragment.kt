package com.veslogger.app.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.veslogger.app.R
import com.veslogger.app.data.model.Measurement
import com.veslogger.app.databinding.FragmentTableBinding
import com.veslogger.app.ui.adapter.MeasurementTableAdapter
import com.veslogger.app.ui.dialog.EditMeasurementDialog
import com.veslogger.app.ui.viewmodel.MeasurementViewModel
import kotlinx.coroutines.launch

class TableFragment : Fragment() {
    
    private var _binding: FragmentTableBinding? = null
    private val binding get() = _binding!!
    
    private val viewModel: MeasurementViewModel by activityViewModels()
    private lateinit var adapter: MeasurementTableAdapter
    
    private enum class SortOrder {
        SEQUENCE_ASC,
        SEQUENCE_DESC,
        AB2_ASC,
        AB2_DESC,
        RESISTIVITY_ASC,
        RESISTIVITY_DESC
    }
    
    private var currentSortOrder = SortOrder.SEQUENCE_ASC
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTableBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupRecyclerView()
        setupClickListeners()
        observeViewModel()
    }
    
    private fun setupRecyclerView() {
        adapter = MeasurementTableAdapter(
            onEditClick = { measurement ->
                showEditDialog(measurement)
            },
            onDeleteClick = { measurement ->
                showDeleteConfirmation(measurement)
            },
            onRowClick = { measurement ->
                // Row selection is handled in adapter
            }
        )
        
        binding.measurementsRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@TableFragment.adapter
        }
    }
    
    private fun setupClickListeners() {
        binding.sortButton.setOnClickListener {
            showSortOptions()
        }
    }
    
    private fun observeViewModel() {
        viewModel.measurements.observe(viewLifecycleOwner) { measurements ->
            updateTable(measurements)
        }
    }
    
    private fun updateTable(measurements: List<Measurement>) {
        if (measurements.isEmpty()) {
            binding.emptyStateLayout.visibility = View.VISIBLE
            binding.measurementsRecyclerView.visibility = View.GONE
        } else {
            binding.emptyStateLayout.visibility = View.GONE
            binding.measurementsRecyclerView.visibility = View.VISIBLE
            
            val sortedMeasurements = sortMeasurements(measurements)
            adapter.submitList(sortedMeasurements)
        }
    }
    
    private fun sortMeasurements(measurements: List<Measurement>): List<Measurement> {
        return when (currentSortOrder) {
            SortOrder.SEQUENCE_ASC -> measurements.sortedBy { it.sequenceNumber }
            SortOrder.SEQUENCE_DESC -> measurements.sortedByDescending { it.sequenceNumber }
            SortOrder.AB2_ASC -> measurements.sortedBy { it.ab2 }
            SortOrder.AB2_DESC -> measurements.sortedByDescending { it.ab2 }
            SortOrder.RESISTIVITY_ASC -> measurements.sortedBy { it.apparentResistivity }
            SortOrder.RESISTIVITY_DESC -> measurements.sortedByDescending { it.apparentResistivity }
        }
    }
    
    private fun showSortOptions() {
        val options = arrayOf(
            "Sıra Numarası (Artan)",
            "Sıra Numarası (Azalan)",
            "AB/2 (Artan)",
            "AB/2 (Azalan)",
            "ρa (Artan)",
            "ρa (Azalan)"
        )
        
        AlertDialog.Builder(requireContext())
            .setTitle("Sıralama")
            .setItems(options) { _, which ->
                currentSortOrder = when (which) {
                    0 -> SortOrder.SEQUENCE_ASC
                    1 -> SortOrder.SEQUENCE_DESC
                    2 -> SortOrder.AB2_ASC
                    3 -> SortOrder.AB2_DESC
                    4 -> SortOrder.RESISTIVITY_ASC
                    5 -> SortOrder.RESISTIVITY_DESC
                    else -> SortOrder.SEQUENCE_ASC
                }
                
                // Re-sort current data
                viewModel.measurements.value?.let { measurements ->
                    updateTable(measurements)
                }
            }
            .show()
    }
    
    private fun showEditDialog(measurement: Measurement) {
        val dialog = EditMeasurementDialog.newInstance(measurement) { updatedMeasurement ->
            lifecycleScope.launch {
                try {
                    viewModel.saveMeasurement(updatedMeasurement)
                } catch (e: Exception) {
                    // Handle error
                }
            }
        }
        dialog.show(parentFragmentManager, "EditMeasurement")
    }
    
    private fun showDeleteConfirmation(measurement: Measurement) {
        AlertDialog.Builder(requireContext())
            .setTitle("Ölçümü Sil")
            .setMessage("Bu ölçümü silmek istediğinizden emin misiniz?")
            .setPositiveButton("Sil") { _, _ ->
                deleteMeasurement(measurement)
            }
            .setNegativeButton("İptal", null)
            .show()
    }
    
    private fun deleteMeasurement(measurement: Measurement) {
        lifecycleScope.launch {
            try {
                viewModel.deleteMeasurement(measurement)
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    companion object {
        fun newInstance() = TableFragment()
    }
}





