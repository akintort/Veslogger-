package com.veslogger.app.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MeasurementPlan(
    val ab2Values: List<Double>,
    val mn2Values: List<Double>
) : Parcelable {
    
    /**
     * Get measurement plan as list of electrode spacing pairs
     */
    fun getMeasurementPairs(): List<Pair<Double, Double>> {
        return ab2Values.zip(mn2Values)
    }
    
    /**
     * Get total number of measurements
     */
    fun getTotalMeasurements(): Int {
        return minOf(ab2Values.size, mn2Values.size)
    }
    
    /**
     * Validate the measurement plan
     */
    fun isValid(): Boolean {
        if (ab2Values.isEmpty() || mn2Values.isEmpty()) return false
        if (ab2Values.size != mn2Values.size) return false
        
        return ab2Values.zip(mn2Values).all { (ab2, mn2) ->
            ab2 > 0 && mn2 > 0 && ab2 > mn2
        }
    }
    
    companion object {
        /**
         * Create measurement plan from CSV data
         */
        fun fromCsvData(csvLines: List<String>): MeasurementPlan? {
            try {
                val ab2List = mutableListOf<Double>()
                val mn2List = mutableListOf<Double>()
                
                csvLines.forEach { line ->
                    val values = line.split(",").map { it.trim() }
                    if (values.size >= 2) {
                        val ab2 = values[0].toDoubleOrNull()
                        val mn2 = values[1].toDoubleOrNull()
                        
                        if (ab2 != null && mn2 != null && ab2 > 0 && mn2 > 0 && ab2 > mn2) {
                            ab2List.add(ab2)
                            mn2List.add(mn2)
                        }
                    }
                }
                
                if (ab2List.isEmpty()) return null
                
                val plan = MeasurementPlan(ab2List, mn2List)
                return if (plan.isValid()) plan else null
                
            } catch (e: Exception) {
                return null
            }
        }
        
        /**
         * Create a standard Schlumberger measurement plan
         */
        fun createStandardSchlumbergerPlan(): MeasurementPlan {
            val ab2Values = listOf(
                1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0,
                12.0, 15.0, 20.0, 25.0, 30.0, 40.0, 50.0,
                60.0, 80.0, 100.0, 120.0, 150.0, 200.0
            )
            val mn2Values = List(ab2Values.size) { 0.5 }
            
            return MeasurementPlan(ab2Values, mn2Values)
        }
    }
}





