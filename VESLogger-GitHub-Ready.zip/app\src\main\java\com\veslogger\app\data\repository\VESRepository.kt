package com.veslogger.app.data.repository

import androidx.lifecycle.LiveData
import com.veslogger.app.data.dao.MeasurementDao
import com.veslogger.app.data.dao.ProjectDao
import com.veslogger.app.data.model.Measurement
import com.veslogger.app.data.model.MeasurementPlan
import com.veslogger.app.data.model.Project
class VESRepository(
    private val projectDao: ProjectDao,
    private val measurementDao: MeasurementDao
) {
    
    // Project operations
    fun getAllProjects(): LiveData<List<Project>> = projectDao.getAllProjects()
    
    suspend fun getProjectById(projectId: String): Project? = projectDao.getProjectById(projectId)
    
    fun getProjectByIdLiveData(projectId: String): LiveData<Project?> = 
        projectDao.getProjectByIdLiveData(projectId)
    
    suspend fun insertProject(project: Project): Long = projectDao.insertProject(project)
    
    suspend fun updateProject(project: Project) = projectDao.updateProject(project)
    
    suspend fun deleteProject(project: Project) = projectDao.deleteProject(project)
    
    suspend fun updateProjectModifiedTime(projectId: String) = 
        projectDao.updateModifiedTime(projectId)
    
    // Measurement operations
    fun getMeasurementsByProject(projectId: String): LiveData<List<Measurement>> = 
        measurementDao.getMeasurementsByProject(projectId)
    
    suspend fun getMeasurementsByProjectSync(projectId: String): List<Measurement> = 
        measurementDao.getMeasurementsByProjectSync(projectId)
    
    suspend fun insertMeasurement(measurement: Measurement): Long = 
        measurementDao.insertMeasurement(measurement)
    
    suspend fun insertMeasurements(measurements: List<Measurement>) = 
        measurementDao.insertMeasurements(measurements)
    
    suspend fun updateMeasurement(measurement: Measurement) = 
        measurementDao.updateMeasurement(measurement)
    
    suspend fun deleteMeasurement(measurement: Measurement) = 
        measurementDao.deleteMeasurement(measurement)
    
    suspend fun getMeasurementCount(projectId: String): Int = 
        measurementDao.getMeasurementCount(projectId)
    
    suspend fun getCompletedMeasurementCount(projectId: String): Int = 
        measurementDao.getCompletedMeasurementCount(projectId)
    
    suspend fun getNextIncompleteMeasurement(projectId: String): Measurement? = 
        measurementDao.getNextIncompleteMeasurement(projectId)
    
    suspend fun updateMeasurementResistance(measurementId: String, resistance: Double) = 
        measurementDao.updateMeasurementResistance(measurementId, resistance)
    
    suspend fun getValidMeasurementsForGraph(projectId: String): List<Measurement> = 
        measurementDao.getValidMeasurementsForGraph(projectId)
    
    // Plan mode operations
    suspend fun createMeasurementsFromPlan(projectId: String, plan: MeasurementPlan): List<Measurement> {
        val measurements = plan.getMeasurementPairs().mapIndexed { index, (ab2, mn2) ->
            Measurement.create(
                projectId = projectId,
                sequenceNumber = index + 1,
                ab2 = ab2,
                mn2 = mn2
            )
        }
        
        insertMeasurements(measurements)
        return measurements
    }
    
    // Data quality operations
    suspend fun checkDataQuality(projectId: String, newMeasurement: Measurement): DataQualityResult {
        val existingMeasurements = getMeasurementsByProjectSync(projectId)
            .filter { it.isValid() && it.sequenceNumber < newMeasurement.sequenceNumber }
            .sortedBy { it.sequenceNumber }
        
        if (existingMeasurements.isEmpty() || !newMeasurement.isValid()) {
            return DataQualityResult.Normal
        }
        
        val lastMeasurement = existingMeasurements.lastOrNull()
        if (lastMeasurement != null) {
            val ratio = newMeasurement.apparentResistivity / lastMeasurement.apparentResistivity
            
            // Check if the new value is significantly different (5x or 1/5x)
            if (ratio >= 5.0 || ratio <= 0.2) {
                return DataQualityResult.Warning(ratio)
            }
        }
        
        return DataQualityResult.Normal
    }
}

sealed class DataQualityResult {
    object Normal : DataQualityResult()
    data class Warning(val ratio: Double) : DataQualityResult()
}





