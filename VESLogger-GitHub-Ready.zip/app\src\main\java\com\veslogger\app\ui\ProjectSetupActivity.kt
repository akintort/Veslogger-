package com.veslogger.app.ui

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.veslogger.app.R
import com.veslogger.app.data.database.VESDatabase
import com.veslogger.app.data.model.MeasurementMode
import com.veslogger.app.data.model.MeasurementPlan
import com.veslogger.app.data.model.Project
import com.veslogger.app.data.repository.VESRepository
import com.veslogger.app.databinding.ActivityProjectSetupBinding
import com.veslogger.app.utils.FileUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ProjectSetupActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityProjectSetupBinding
    private lateinit var repository: VESRepository
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var selectedCsvUri: Uri? = null
    private var measurementPlan: MeasurementPlan? = null
    
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private var selectedDate = Calendar.getInstance()
    
    private val csvFilePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { handleCsvFileSelection(it) }
    }
    
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseLocationGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        
        if (fineLocationGranted || coarseLocationGranted) {
            getCurrentLocation()
        } else {
            Toast.makeText(this, getString(R.string.location_permission_required), Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        initializeComponents()
        setupUI()
        setupClickListeners()
    }
    
    private fun initializeComponents() {
        val database = VESDatabase.getDatabase(this)
        repository = VESRepository(database.projectDao(), database.measurementDao())
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
    }
    
    private fun setupUI() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        // Set current date
        binding.dateEditText.setText(dateFormat.format(selectedDate.time))
        
        // Setup measurement mode radio group
        binding.measurementModeRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.manualModeRadio -> {
                    binding.csvFileLayout.visibility = android.view.View.GONE
                }
                R.id.planModeRadio -> {
                    binding.csvFileLayout.visibility = android.view.View.VISIBLE
                }
            }
        }
    }
    
    private fun setupClickListeners() {
        binding.toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
        
        binding.dateEditText.setOnClickListener {
            showDatePicker()
        }
        
        binding.getLocationButton.setOnClickListener {
            requestLocationPermission()
        }
        
        binding.selectCsvButton.setOnClickListener {
            csvFilePickerLauncher.launch("text/*")
        }
        
        binding.cancelButton.setOnClickListener {
            onBackPressed()
        }
        
        binding.createProjectButton.setOnClickListener {
            createProject()
        }
    }
    
    private fun showDatePicker() {
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedDate.set(year, month, dayOfMonth)
                binding.dateEditText.setText(dateFormat.format(selectedDate.time))
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        ).show()
    }
    
    private fun requestLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }
    
    private fun getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            location?.let {
                binding.latitudeEditText.setText(String.format("%.6f", it.latitude))
                binding.longitudeEditText.setText(String.format("%.6f", it.longitude))
                binding.altitudeEditText.setText(String.format("%.1f", it.altitude))
                Toast.makeText(this, "Konum alındı", Toast.LENGTH_SHORT).show()
            } ?: run {
                Toast.makeText(this, getString(R.string.location_not_available), Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {
            Toast.makeText(this, getString(R.string.location_not_available), Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun handleCsvFileSelection(uri: Uri) {
        try {
            val fileName = FileUtils.getFileName(this, uri)
            val csvContent = FileUtils.readTextFromUri(this, uri)
            val lines = csvContent.split("\n").filter { it.isNotBlank() }
            
            measurementPlan = MeasurementPlan.fromCsvData(lines)
            
            if (measurementPlan != null && measurementPlan!!.isValid()) {
                selectedCsvUri = uri
                binding.selectedFileTextView.text = "$fileName (${measurementPlan!!.getTotalMeasurements()} ölçüm)"
                binding.selectedFileTextView.alpha = 1.0f
                Toast.makeText(this, getString(R.string.plan_loaded, measurementPlan!!.getTotalMeasurements()), Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, getString(R.string.invalid_csv_format), Toast.LENGTH_LONG).show()
                binding.selectedFileTextView.text = "Geçersiz dosya formatı"
                binding.selectedFileTextView.alpha = 0.6f
                selectedCsvUri = null
                measurementPlan = null
            }
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.file_import_failed), Toast.LENGTH_LONG).show()
            binding.selectedFileTextView.text = "Dosya okuma hatası"
            binding.selectedFileTextView.alpha = 0.6f
            selectedCsvUri = null
            measurementPlan = null
        }
    }
    
    private fun createProject() {
        if (!validateInputs()) return
        
        val projectName = binding.projectNameEditText.text.toString().trim()
        val pointId = binding.pointIdEditText.text.toString().trim()
        val notes = binding.notesEditText.text.toString().trim()
        
        val latitude = binding.latitudeEditText.text.toString().toDoubleOrNull()
        val longitude = binding.longitudeEditText.text.toString().toDoubleOrNull()
        val altitude = binding.altitudeEditText.text.toString().toDoubleOrNull()
        
        val measurementMode = if (binding.manualModeRadio.isChecked) {
            MeasurementMode.MANUAL
        } else {
            MeasurementMode.PLAN
        }
        
        val project = Project(
            name = projectName,
            pointId = pointId,
            date = selectedDate.timeInMillis,
            latitude = latitude,
            longitude = longitude,
            altitude = altitude,
            notes = notes,
            measurementMode = measurementMode
        )
        
        lifecycleScope.launch {
            try {
                repository.insertProject(project)
                
                // If plan mode is selected, create measurements from plan
                if (measurementMode == MeasurementMode.PLAN && measurementPlan != null) {
                    repository.createMeasurementsFromPlan(project.id, measurementPlan!!)
                }
                
                // Start measurement activity
                val intent = Intent(this@ProjectSetupActivity, MeasurementActivity::class.java).apply {
                    putExtra(MeasurementActivity.EXTRA_PROJECT_ID, project.id)
                }
                startActivity(intent)
                finish()
                
            } catch (e: Exception) {
                Toast.makeText(this@ProjectSetupActivity, getString(R.string.database_error), Toast.LENGTH_LONG).show()
            }
        }
    }
    
    private fun validateInputs(): Boolean {
        var isValid = true
        
        if (binding.projectNameEditText.text.toString().trim().isEmpty()) {
            binding.projectNameInputLayout.error = getString(R.string.field_required)
            isValid = false
        } else {
            binding.projectNameInputLayout.error = null
        }
        
        if (binding.pointIdEditText.text.toString().trim().isEmpty()) {
            binding.pointIdInputLayout.error = getString(R.string.field_required)
            isValid = false
        } else {
            binding.pointIdInputLayout.error = null
        }
        
        // Validate plan mode requirements
        if (binding.planModeRadio.isChecked) {
            if (selectedCsvUri == null || measurementPlan == null) {
                Toast.makeText(this, "Plan modu için geçerli bir CSV dosyası seçmelisiniz", Toast.LENGTH_LONG).show()
                isValid = false
            }
        }
        
        return isValid
    }
}





