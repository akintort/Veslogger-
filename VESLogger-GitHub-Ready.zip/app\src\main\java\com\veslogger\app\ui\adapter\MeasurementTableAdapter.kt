package com.veslogger.app.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.veslogger.app.R
import com.veslogger.app.data.model.Measurement
import com.veslogger.app.databinding.ItemMeasurementTableBinding

class MeasurementTableAdapter(
    private val onEditClick: (Measurement) -> Unit,
    private val onDeleteClick: (Measurement) -> Unit,
    private val onRowClick: (Measurement) -> Unit
) : ListAdapter<Measurement, MeasurementTableAdapter.ViewHolder>(DiffCallback()) {

    private var selectedPosition = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemMeasurementTableBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), position == selectedPosition)
    }

    fun setSelectedPosition(position: Int) {
        val previousPosition = selectedPosition
        selectedPosition = position
        
        if (previousPosition != -1) {
            notifyItemChanged(previousPosition)
        }
        if (selectedPosition != -1) {
            notifyItemChanged(selectedPosition)
        }
    }

    inner class ViewHolder(
        private val binding: ItemMeasurementTableBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(measurement: Measurement, isSelected: Boolean) {
            binding.apply {
                sequenceTextView.text = measurement.sequenceNumber.toString()
                ab2TextView.text = String.format("%.1f", measurement.ab2)
                mn2TextView.text = String.format("%.1f", measurement.mn2)
                
                if (measurement.resistance != null) {
                    resistanceTextView.text = String.format("%.2f", measurement.resistance)
                } else {
                    resistanceTextView.text = "-"
                }
                
                kFactorTextView.text = String.format("%.2f", measurement.kFactor)
                resistivityTextView.text = String.format("%.2f", measurement.apparentResistivity)

                // Set row background based on selection and completion status
                val backgroundColor = when {
                    isSelected -> ContextCompat.getColor(root.context, R.color.row_selected)
                    measurement.isCompleted -> ContextCompat.getColor(root.context, R.color.row_completed)
                    else -> ContextCompat.getColor(root.context, android.R.color.transparent)
                }
                rowLayout.setBackgroundColor(backgroundColor)

                // Set click listeners
                root.setOnClickListener {
                    setSelectedPosition(adapterPosition)
                    onRowClick(measurement)
                }

                editButton.setOnClickListener {
                    onEditClick(measurement)
                }

                deleteButton.setOnClickListener {
                    onDeleteClick(measurement)
                }
            }
        }
    }

    private class DiffCallback : DiffUtil.ItemCallback<Measurement>() {
        override fun areItemsTheSame(oldItem: Measurement, newItem: Measurement): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Measurement, newItem: Measurement): Boolean {
            return oldItem == newItem
        }
    }
}





