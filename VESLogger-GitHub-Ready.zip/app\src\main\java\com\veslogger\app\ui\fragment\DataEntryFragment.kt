package com.veslogger.app.ui.fragment

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.veslogger.app.R
import com.veslogger.app.data.model.Measurement
import com.veslogger.app.data.model.MeasurementMode
import com.veslogger.app.data.repository.DataQualityResult
import com.veslogger.app.databinding.FragmentDataEntryBinding
import com.veslogger.app.ui.viewmodel.MeasurementViewModel
import com.veslogger.app.ui.dialog.DataQualityWarningDialog
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.pow

class DataEntryFragment : Fragment() {
    
    private var _binding: FragmentDataEntryBinding? = null
    private val binding get() = _binding!!
    
    private val viewModel: MeasurementViewModel by activityViewModels()
    private var currentMeasurement: Measurement? = null
    private var measurementMode = MeasurementMode.MANUAL
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDataEntryBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        observeViewModel()
        setupTextWatchers()
        setupClickListeners()
    }
    
    private fun observeViewModel() {
        viewModel.project.observe(viewLifecycleOwner) { project ->
            project?.let {
                measurementMode = it.measurementMode
                updateUIForMode()
            }
        }
        
        viewModel.measurements.observe(viewLifecycleOwner) { measurements ->
            updateStatistics(measurements)
        }
        
        viewModel.nextIncompleteMeasurement.observe(viewLifecycleOwner) { measurement ->
            if (measurementMode == MeasurementMode.PLAN) {
                currentMeasurement = measurement
                updatePlanModeUI()
            }
        }
        
        viewModel.measurementCounts.observe(viewLifecycleOwner) { (total, completed) ->
            binding.totalMeasurementsTextView.text = total.toString()
            binding.completedMeasurementsTextView.text = completed.toString()
            
            if (measurementMode == MeasurementMode.PLAN) {
                updateProgressText(completed, total)
            }
        }
    }
    
    private fun updateUIForMode() {
        when (measurementMode) {
            MeasurementMode.MANUAL -> {
                binding.manualInputCard.visibility = View.VISIBLE
                binding.planInputCard.visibility = View.GONE
            }
            MeasurementMode.PLAN -> {
                binding.manualInputCard.visibility = View.GONE
                binding.planInputCard.visibility = View.VISIBLE
            }
        }
    }
    
    private fun updatePlanModeUI() {
        currentMeasurement?.let { measurement ->
            binding.currentAb2TextView.text = "${measurement.ab2} m"
            binding.currentMn2TextView.text = "${measurement.mn2} m"
            binding.planResistanceEditText.setText("")
            binding.planResistanceEditText.requestFocus()
        }
    }
    
    private fun updateProgressText(completed: Int, total: Int) {
        binding.currentMeasurementTextView.text = 
            getString(R.string.current_measurement, completed + 1, total)
    }
    
    private fun setupTextWatchers() {
        // Manual mode text watchers
        val manualTextWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                calculateAndDisplayValues()
            }
        }
        
        binding.ab2EditText.addTextChangedListener(manualTextWatcher)
        binding.mn2EditText.addTextChangedListener(manualTextWatcher)
        binding.resistanceEditText.addTextChangedListener(manualTextWatcher)
    }
    
    private fun setupClickListeners() {
        binding.addMeasurementButton.setOnClickListener {
            addManualMeasurement()
        }
        
        binding.confirmButton.setOnClickListener {
            confirmPlanMeasurement()
        }
        
        binding.previousButton.setOnClickListener {
            // Navigate to previous measurement in plan mode
            // This would be implemented based on your navigation logic
        }
    }
    
    private fun calculateAndDisplayValues() {
        val ab2Text = binding.ab2EditText.text.toString()
        val mn2Text = binding.mn2EditText.text.toString()
        val resistanceText = binding.resistanceEditText.text.toString()
        
        val ab2 = ab2Text.toDoubleOrNull()
        val mn2 = mn2Text.toDoubleOrNull()
        val resistance = resistanceText.toDoubleOrNull()
        
        if (ab2 != null && mn2 != null && ab2 > 0 && mn2 > 0 && ab2 > mn2) {
            val k = PI * ((ab2.pow(2) - mn2.pow(2)) / (2 * mn2))
            binding.kFactorTextView.text = String.format("%.2f", k)
            
            if (resistance != null && resistance > 0) {
                val rho = k * resistance
                binding.resistivityTextView.text = String.format("%.2f Ω.m", rho)
            } else {
                binding.resistivityTextView.text = "0.00 Ω.m"
            }
        } else {
            binding.kFactorTextView.text = "0.00"
            binding.resistivityTextView.text = "0.00 Ω.m"
        }
    }
    
    private fun addManualMeasurement() {
        if (!validateManualInputs()) return
        
        val ab2 = binding.ab2EditText.text.toString().toDouble()
        val mn2 = binding.mn2EditText.text.toString().toDouble()
        val resistance = binding.resistanceEditText.text.toString().toDouble()
        
        lifecycleScope.launch {
            try {
                val nextSequenceNumber = viewModel.getNextSequenceNumber()
                val measurement = Measurement.create(
                    projectId = viewModel.projectId,
                    sequenceNumber = nextSequenceNumber,
                    ab2 = ab2,
                    mn2 = mn2,
                    resistance = resistance
                )
                
                // Check data quality
                val qualityResult = viewModel.checkDataQuality(measurement)
                
                when (qualityResult) {
                    is DataQualityResult.Warning -> {
                        showDataQualityWarning(measurement, qualityResult.ratio)
                    }
                    DataQualityResult.Normal -> {
                        saveMeasurement(measurement)
                    }
                }
                
            } catch (e: Exception) {
                Toast.makeText(requireContext(), getString(R.string.calculation_error), Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun confirmPlanMeasurement() {
        val resistanceText = binding.planResistanceEditText.text.toString()
        if (resistanceText.isEmpty()) {
            binding.planResistanceInputLayout.error = getString(R.string.field_required)
            return
        }
        
        val resistance = resistanceText.toDoubleOrNull()
        if (resistance == null || resistance <= 0) {
            binding.planResistanceInputLayout.error = getString(R.string.invalid_number)
            return
        }
        
        binding.planResistanceInputLayout.error = null
        
        currentMeasurement?.let { measurement ->
            val updatedMeasurement = measurement.copy(resistance = resistance).withCalculatedValues()
            
            lifecycleScope.launch {
                try {
                    // Check data quality
                    val qualityResult = viewModel.checkDataQuality(updatedMeasurement)
                    
                    when (qualityResult) {
                        is DataQualityResult.Warning -> {
                            showDataQualityWarning(updatedMeasurement, qualityResult.ratio)
                        }
                        DataQualityResult.Normal -> {
                            saveMeasurement(updatedMeasurement)
                        }
                    }
                    
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), getString(R.string.calculation_error), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun showDataQualityWarning(measurement: Measurement, ratio: Double) {
        val dialog = DataQualityWarningDialog.newInstance(ratio) { saveAnyway ->
            if (saveAnyway) {
                saveMeasurement(measurement)
            }
        }
        dialog.show(parentFragmentManager, "DataQualityWarning")
    }
    
    private fun saveMeasurement(measurement: Measurement) {
        lifecycleScope.launch {
            try {
                viewModel.saveMeasurement(measurement)
                
                if (measurementMode == MeasurementMode.MANUAL) {
                    clearManualInputs()
                    Toast.makeText(requireContext(), getString(R.string.measurement_added), Toast.LENGTH_SHORT).show()
                } else {
                    // In plan mode, automatically move to next measurement
                    viewModel.loadNextIncompleteMeasurement()
                    Toast.makeText(requireContext(), getString(R.string.measurement_completed), Toast.LENGTH_SHORT).show()
                }
                
            } catch (e: Exception) {
                Toast.makeText(requireContext(), getString(R.string.database_error), Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun validateManualInputs(): Boolean {
        var isValid = true
        
        val ab2Text = binding.ab2EditText.text.toString()
        val mn2Text = binding.mn2EditText.text.toString()
        val resistanceText = binding.resistanceEditText.text.toString()
        
        if (ab2Text.isEmpty()) {
            binding.ab2InputLayout.error = getString(R.string.field_required)
            isValid = false
        } else {
            val ab2 = ab2Text.toDoubleOrNull()
            if (ab2 == null || ab2 <= 0) {
                binding.ab2InputLayout.error = getString(R.string.value_must_be_positive)
                isValid = false
            } else {
                binding.ab2InputLayout.error = null
            }
        }
        
        if (mn2Text.isEmpty()) {
            binding.mn2InputLayout.error = getString(R.string.field_required)
            isValid = false
        } else {
            val mn2 = mn2Text.toDoubleOrNull()
            if (mn2 == null || mn2 <= 0) {
                binding.mn2InputLayout.error = getString(R.string.value_must_be_positive)
                isValid = false
            } else {
                binding.mn2InputLayout.error = null
            }
        }
        
        if (resistanceText.isEmpty()) {
            binding.resistanceInputLayout.error = getString(R.string.field_required)
            isValid = false
        } else {
            val resistance = resistanceText.toDoubleOrNull()
            if (resistance == null || resistance <= 0) {
                binding.resistanceInputLayout.error = getString(R.string.value_must_be_positive)
                isValid = false
            } else {
                binding.resistanceInputLayout.error = null
            }
        }
        
        // Check if AB/2 > MN/2
        val ab2 = ab2Text.toDoubleOrNull()
        val mn2 = mn2Text.toDoubleOrNull()
        if (ab2 != null && mn2 != null && ab2 <= mn2) {
            binding.ab2InputLayout.error = getString(R.string.ab_must_be_greater_than_mn)
            isValid = false
        }
        
        return isValid
    }
    
    private fun clearManualInputs() {
        binding.ab2EditText.setText("")
        binding.mn2EditText.setText("")
        binding.resistanceEditText.setText("")
        binding.kFactorTextView.text = "0.00"
        binding.resistivityTextView.text = "0.00 Ω.m"
    }
    
    private fun updateStatistics(measurements: List<Measurement>) {
        binding.totalMeasurementsTextView.text = measurements.size.toString()
        binding.completedMeasurementsTextView.text = measurements.count { it.isCompleted }.toString()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    companion object {
        fun newInstance() = DataEntryFragment()
    }
}





