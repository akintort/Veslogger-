package com.veslogger.app.ui.fragment

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.veslogger.app.R
import com.veslogger.app.data.model.Project
import com.veslogger.app.databinding.FragmentExportBinding
import com.veslogger.app.ui.viewmodel.MeasurementViewModel
import com.veslogger.app.utils.FileUtils
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class ExportFragment : Fragment() {
    
    private var _binding: FragmentExportBinding? = null
    private val binding get() = _binding!!
    
    private val viewModel: MeasurementViewModel by activityViewModels()
    private var currentProject: Project? = null
    
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentExportBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupClickListeners()
        observeViewModel()
    }
    
    private fun setupClickListeners() {
        binding.csvExportLayout.setOnClickListener {
            exportToCsv()
        }
        
        binding.pdfExportLayout.setOnClickListener {
            exportToPdf()
        }
        
        binding.imageExportLayout.setOnClickListener {
            exportGraphImage()
        }
        
        binding.shareButton.setOnClickListener {
            shareData()
        }
        
        binding.emailButton.setOnClickListener {
            sendEmail()
        }
    }
    
    private fun observeViewModel() {
        viewModel.project.observe(viewLifecycleOwner) { project ->
            currentProject = project
            updateProjectInfo(project)
        }
        
        viewModel.measurementCounts.observe(viewLifecycleOwner) { (total, completed) ->
            binding.totalMeasurementsTextView.text = total.toString()
            binding.completedMeasurementsTextView.text = completed.toString()
        }
    }
    
    private fun updateProjectInfo(project: Project?) {
        project?.let {
            binding.projectNameTextView.text = it.name
            binding.pointIdTextView.text = it.pointId
        }
    }
    
    private fun exportToCsv() {
        lifecycleScope.launch {
            try {
                val measurements = viewModel.exportMeasurements()
                if (measurements.isEmpty()) {
                    Toast.makeText(requireContext(), "Dışa aktarılacak veri yok", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                val csvContent = FileUtils.createCsvContent(measurements)
                val fileName = FileUtils.generateUniqueFileName(
                    "${currentProject?.name}_${currentProject?.pointId}",
                    "csv"
                )
                
                val file = File(requireContext().getExternalFilesDir(null), fileName)
                file.writeText(csvContent)
                
                val uri = FileProvider.getUriForFile(
                    requireContext(),
                    "${requireContext().packageName}.fileprovider",
                    file
                )
                
                shareFile(uri, "text/csv")
                Toast.makeText(requireContext(), getString(R.string.file_saved, file.name), Toast.LENGTH_LONG).show()
                
            } catch (e: Exception) {
                Toast.makeText(requireContext(), getString(R.string.file_export_failed), Toast.LENGTH_LONG).show()
            }
        }
    }
    
    private fun exportToPdf() {
        Toast.makeText(requireContext(), "PDF dışa aktarma henüz hazır değil", Toast.LENGTH_SHORT).show()
        // TODO: Implement PDF export with graph and table
    }
    
    private fun exportGraphImage() {
        // Find the graph fragment and capture its chart view
        val graphFragment = parentFragmentManager.findFragmentByTag("graph") as? GraphFragment
        if (graphFragment != null) {
            lifecycleScope.launch {
                try {
                    // This would need to be implemented in GraphFragment
                    // val bitmap = graphFragment.captureChart()
                    // saveImageToFile(bitmap)
                    Toast.makeText(requireContext(), "Grafik görüntüsü dışa aktarma henüz hazır değil", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Grafik kaydedilemedi", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(requireContext(), "Grafik bulunamadı", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun saveImageToFile(bitmap: Bitmap) {
        try {
            val fileName = FileUtils.generateUniqueFileName(
                "${currentProject?.name}_${currentProject?.pointId}_graph",
                "png"
            )
            
            val file = File(requireContext().getExternalFilesDir(null), fileName)
            val outputStream = FileOutputStream(file)
            
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            outputStream.flush()
            outputStream.close()
            
            val uri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.fileprovider",
                file
            )
            
            shareFile(uri, "image/png")
            Toast.makeText(requireContext(), getString(R.string.file_saved, file.name), Toast.LENGTH_LONG).show()
            
        } catch (e: IOException) {
            Toast.makeText(requireContext(), "Görüntü kaydedilemedi", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun shareData() {
        lifecycleScope.launch {
            try {
                val measurements = viewModel.exportMeasurements()
                if (measurements.isEmpty()) {
                    Toast.makeText(requireContext(), "Paylaşılacak veri yok", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                val csvContent = FileUtils.createCsvContent(measurements)
                val fileName = "${currentProject?.name}_${currentProject?.pointId}.csv"
                
                val file = File(requireContext().cacheDir, fileName)
                file.writeText(csvContent)
                
                val uri = FileProvider.getUriForFile(
                    requireContext(),
                    "${requireContext().packageName}.fileprovider",
                    file
                )
                
                shareFile(uri, "text/csv")
                
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Paylaşım başarısız", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun sendEmail() {
        lifecycleScope.launch {
            try {
                val measurements = viewModel.exportMeasurements()
                if (measurements.isEmpty()) {
                    Toast.makeText(requireContext(), "Gönderilecek veri yok", Toast.LENGTH_SHORT).show()
                    return@launch
                }
                
                val csvContent = FileUtils.createCsvContent(measurements)
                val fileName = "${currentProject?.name}_${currentProject?.pointId}.csv"
                
                val file = File(requireContext().cacheDir, fileName)
                file.writeText(csvContent)
                
                val uri = FileProvider.getUriForFile(
                    requireContext(),
                    "${requireContext().packageName}.fileprovider",
                    file
                )
                
                val emailIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_EMAIL, arrayOf<String>())
                    putExtra(Intent.EXTRA_SUBJECT, "VES Ölçüm Verileri - ${currentProject?.name}")
                    putExtra(Intent.EXTRA_TEXT, createEmailBody())
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                
                startActivity(Intent.createChooser(emailIntent, "E-posta Gönder"))
                
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "E-posta gönderimi başarısız", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun createEmailBody(): String {
        val project = currentProject ?: return ""
        
        return buildString {
            append("VESLogger - Düşey Elektrik Sondaj Verileri\n\n")
            append("Proje Bilgileri:\n")
            append("- Proje Adı: ${project.name}\n")
            append("- Nokta ID: ${project.pointId}\n")
            append("- Tarih: ${dateFormat.format(Date(project.date))}\n")
            
            if (project.latitude != null && project.longitude != null) {
                append("- Koordinatlar: ${project.latitude}, ${project.longitude}\n")
            }
            
            if (project.notes.isNotEmpty()) {
                append("- Notlar: ${project.notes}\n")
            }
            
            append("\nEkteki CSV dosyasında ölçüm verileri bulunmaktadır.\n\n")
            append("Bu veriler VESLogger uygulaması ile oluşturulmuştur.")
        }
    }
    
    private fun shareFile(uri: Uri, mimeType: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        
        startActivity(Intent.createChooser(shareIntent, "Dosyayı Paylaş"))
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    companion object {
        fun newInstance() = ExportFragment()
    }
}





