package com.veslogger.app.ui.fragment

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.veslogger.app.data.model.Measurement
import com.veslogger.app.databinding.FragmentGraphBinding
import com.veslogger.app.ui.viewmodel.MeasurementViewModel
import kotlinx.coroutines.launch

class GraphFragment : Fragment() {
    
    private var _binding: FragmentGraphBinding? = null
    private val binding get() = _binding!!
    
    private val viewModel: MeasurementViewModel by activityViewModels()
    private var isFullscreen = false
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGraphBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        setupUI()
        observeViewModel()
        loadGraphData()
    }
    
    private fun setupUI() {
        binding.fullscreenButton.setOnClickListener {
            toggleFullscreen()
        }
        
        binding.vesChartView.onPointSelected = { measurement ->
            showPointInfo(measurement)
        }
    }
    
    private fun observeViewModel() {
        viewModel.measurements.observe(viewLifecycleOwner) { measurements ->
            updateGraph(measurements.filter { it.isValid() })
        }
    }
    
    private fun loadGraphData() {
        lifecycleScope.launch {
            val validMeasurements = viewModel.getValidMeasurementsForGraph()
            updateGraph(validMeasurements)
        }
    }
    
    private fun updateGraph(measurements: List<Measurement>) {
        if (measurements.isEmpty()) {
            binding.noDataLayout.visibility = View.VISIBLE
            binding.vesChartView.visibility = View.GONE
        } else {
            binding.noDataLayout.visibility = View.GONE
            binding.vesChartView.visibility = View.VISIBLE
            binding.vesChartView.setMeasurements(measurements)
        }
    }
    
    private fun showPointInfo(measurement: Measurement) {
        binding.pointInfoCard.visibility = View.VISIBLE
        binding.pointInfoAB2.text = "AB/2: ${measurement.ab2} m"
        binding.pointInfoResistivity.text = "ρa: ${String.format("%.2f", measurement.apparentResistivity)} Ω.m"
        
        // Hide the info card after 3 seconds
        binding.pointInfoCard.postDelayed({
            binding.pointInfoCard.visibility = View.GONE
        }, 3000)
    }
    
    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        
        if (isFullscreen) {
            // Enter fullscreen mode
            requireActivity().requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            binding.fullscreenButton.text = "Çıkış"
            binding.graphControlsCard.visibility = View.GONE
            
            // Hide system UI
            requireActivity().window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
            
        } else {
            // Exit fullscreen mode
            requireActivity().requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
            binding.fullscreenButton.text = "Tam Ekran"
            binding.graphControlsCard.visibility = View.VISIBLE
            
            // Show system UI
            requireActivity().window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        
        // Ensure we exit fullscreen mode when leaving
        if (isFullscreen) {
            requireActivity().requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
            requireActivity().window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
        
        _binding = null
    }
    
    companion object {
        fun newInstance() = GraphFragment()
    }
}





