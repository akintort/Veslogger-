# VESLogger - Manual Clean PowerShell Script
Write-Host "VESLogger - Manual Clean" -ForegroundColor Green
Write-Host "=========================" -ForegroundColor Green

# Stop all Java processes
Write-Host "1. Stopping Java processes..." -ForegroundColor Yellow
Get-Process | Where-Object {$_.ProcessName -like "*java*"} | Stop-Process -Force -ErrorAction SilentlyContinue

# Remove Gradle cache
Write-Host "2. Removing Gradle cache..." -ForegroundColor Yellow
$gradleHome = "$env:USERPROFILE\.gradle"
if (Test-Path $gradleHome) {
    Remove-Item -Recurse -Force $gradleHome -ErrorAction SilentlyContinue
    Write-Host "Gradle cache removed" -ForegroundColor Green
}

# Remove project build folders
Write-Host "3. Removing project build folders..." -ForegroundColor Yellow
$buildFolders = @("build", "app\build", ".gradle")
foreach ($folder in $buildFolders) {
    if (Test-Path $folder) {
        Remove-Item -Recurse -Force $folder -ErrorAction SilentlyContinue
        Write-Host "Removed $folder" -ForegroundColor Green
    }
}

Write-Host "4. Clean completed!" -ForegroundColor Green
Write-Host "Now run: gradlew clean && gradlew build" -ForegroundColor Cyan

Read-Host "Press Enter to continue"





