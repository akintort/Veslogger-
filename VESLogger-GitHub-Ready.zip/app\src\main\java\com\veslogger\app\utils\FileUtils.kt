package com.veslogger.app.utils

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

object FileUtils {
    
    /**
     * Get file name from URI
     */
    fun getFileName(context: Context, uri: Uri): String {
        var fileName = "unknown_file"
        
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val displayNameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (displayNameIndex >= 0) {
                    fileName = it.getString(displayNameIndex)
                }
            }
        }
        
        return fileName
    }
    
    /**
     * Read text content from URI
     */
    fun readTextFromUri(context: Context, uri: Uri): String {
        val stringBuilder = StringBuilder()
        
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            BufferedReader(InputStreamReader(inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    stringBuilder.append(line).append('\n')
                }
            }
        }
        
        return stringBuilder.toString()
    }
    
    /**
     * Validate CSV format for measurement plan
     */
    fun validateCsvFormat(content: String): Boolean {
        val lines = content.split("\n").filter { it.isNotBlank() }
        
        if (lines.isEmpty()) return false
        
        return lines.all { line ->
            val values = line.split(",").map { it.trim() }
            if (values.size < 2) return@all false
            
            val ab2 = values[0].toDoubleOrNull()
            val mn2 = values[1].toDoubleOrNull()
            
            ab2 != null && mn2 != null && ab2 > 0 && mn2 > 0 && ab2 > mn2
        }
    }
    
    /**
     * Create CSV content from measurements
     */
    fun createCsvContent(measurements: List<com.veslogger.app.data.model.Measurement>): String {
        val stringBuilder = StringBuilder()
        
        // Header
        stringBuilder.append("No,AB/2,MN/2,R,K,ρa\n")
        
        // Data rows
        measurements.forEach { measurement ->
            stringBuilder.append("${measurement.sequenceNumber},")
            stringBuilder.append("${measurement.ab2},")
            stringBuilder.append("${measurement.mn2},")
            stringBuilder.append("${measurement.resistance ?: ""},")
            stringBuilder.append("${measurement.kFactor},")
            stringBuilder.append("${measurement.apparentResistivity}\n")
        }
        
        return stringBuilder.toString()
    }
    
    /**
     * Get file extension from filename
     */
    fun getFileExtension(fileName: String): String {
        return fileName.substringAfterLast('.', "")
    }
    
    /**
     * Generate unique filename with timestamp
     */
    fun generateUniqueFileName(baseName: String, extension: String): String {
        val timestamp = System.currentTimeMillis()
        return "${baseName}_${timestamp}.${extension}"
    }
}





