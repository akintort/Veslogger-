package com.veslogger.app.ui.dialog

import android.app.Dialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import com.veslogger.app.R
import com.veslogger.app.data.model.Measurement
import com.veslogger.app.databinding.DialogEditMeasurementBinding
import kotlin.math.PI
import kotlin.math.pow

class EditMeasurementDialog : DialogFragment() {
    
    private var _binding: DialogEditMeasurementBinding? = null
    private val binding get() = _binding!!
    
    private var measurement: Measurement? = null
    private var onSave: ((Measurement) -> Unit)? = null
    
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogEditMeasurementBinding.inflate(layoutInflater)
        
        measurement = arguments?.getParcelable(ARG_MEASUREMENT)
        
        setupUI()
        setupTextWatchers()
        
        return AlertDialog.Builder(requireContext())
            .setTitle("Ölçümü Düzenle")
            .setView(binding.root)
            .setPositiveButton("Kaydet") { _, _ ->
                saveMeasurement()
            }
            .setNegativeButton("İptal", null)
            .create()
    }
    
    private fun setupUI() {
        measurement?.let { m ->
            binding.ab2EditText.setText(m.ab2.toString())
            binding.mn2EditText.setText(m.mn2.toString())
            binding.resistanceEditText.setText(m.resistance?.toString() ?: "")
            
            updateCalculatedValues()
        }
    }
    
    private fun setupTextWatchers() {
        val textWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateCalculatedValues()
            }
        }
        
        binding.ab2EditText.addTextChangedListener(textWatcher)
        binding.mn2EditText.addTextChangedListener(textWatcher)
        binding.resistanceEditText.addTextChangedListener(textWatcher)
    }
    
    private fun updateCalculatedValues() {
        val ab2Text = binding.ab2EditText.text.toString()
        val mn2Text = binding.mn2EditText.text.toString()
        val resistanceText = binding.resistanceEditText.text.toString()
        
        val ab2 = ab2Text.toDoubleOrNull()
        val mn2 = mn2Text.toDoubleOrNull()
        val resistance = resistanceText.toDoubleOrNull()
        
        if (ab2 != null && mn2 != null && ab2 > 0 && mn2 > 0 && ab2 > mn2) {
            val k = PI * ((ab2.pow(2) - mn2.pow(2)) / (2 * mn2))
            binding.kFactorTextView.text = String.format("%.2f", k)
            
            if (resistance != null && resistance > 0) {
                val rho = k * resistance
                binding.resistivityTextView.text = String.format("%.2f Ω.m", rho)
            } else {
                binding.resistivityTextView.text = "0.00 Ω.m"
            }
        } else {
            binding.kFactorTextView.text = "0.00"
            binding.resistivityTextView.text = "0.00 Ω.m"
        }
    }
    
    private fun saveMeasurement() {
        measurement?.let { original ->
            val ab2 = binding.ab2EditText.text.toString().toDoubleOrNull()
            val mn2 = binding.mn2EditText.text.toString().toDoubleOrNull()
            val resistance = binding.resistanceEditText.text.toString().toDoubleOrNull()
            
            if (ab2 != null && mn2 != null && resistance != null && 
                ab2 > 0 && mn2 > 0 && ab2 > mn2 && resistance > 0) {
                
                val updatedMeasurement = original.copy(
                    ab2 = ab2,
                    mn2 = mn2,
                    resistance = resistance
                ).withCalculatedValues()
                
                onSave?.invoke(updatedMeasurement)
            }
        }
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    companion object {
        private const val ARG_MEASUREMENT = "measurement"
        
        fun newInstance(measurement: Measurement, onSave: (Measurement) -> Unit): EditMeasurementDialog {
            return EditMeasurementDialog().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_MEASUREMENT, measurement)
                }
                this.onSave = onSave
            }
        }
    }
}





