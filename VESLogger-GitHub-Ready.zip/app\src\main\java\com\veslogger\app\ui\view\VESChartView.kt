package com.veslogger.app.ui.view

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import androidx.core.content.ContextCompat
import com.veslogger.app.R
import com.veslogger.app.data.model.Measurement
import kotlin.math.*

class VESChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Paint objects
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val selectedPointPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Data
    private var measurements: List<Measurement> = emptyList()
    private var selectedPointIndex = -1

    // Chart bounds and scaling
    private var chartRect = RectF()
    private var dataMinX = 0.1
    private var dataMaxX = 1000.0
    private var dataMinY = 0.1
    private var dataMaxY = 10000.0
    private var scaleFactorX = 1f
    private var scaleFactorY = 1f
    private var offsetX = 0f
    private var offsetY = 0f

    // Gesture detectors
    private val scaleGestureDetector: ScaleGestureDetector
    private val gestureDetector: GestureDetector

    // Callbacks
    var onPointSelected: ((Measurement) -> Unit)? = null

    init {
        setupPaints()
        
        scaleGestureDetector = ScaleGestureDetector(context, ScaleGestureListener())
        gestureDetector = GestureDetector(context, GestureListener())
    }

    private fun setupPaints() {
        val textColor = ContextCompat.getColor(context, android.R.color.black)
        val gridColor = ContextCompat.getColor(context, R.color.graph_grid)
        val lineColor = ContextCompat.getColor(context, R.color.graph_line)
        val pointColor = ContextCompat.getColor(context, R.color.graph_point)

        axisPaint.apply {
            color = textColor
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }

        gridPaint.apply {
            color = gridColor
            strokeWidth = 1f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(5f, 5f), 0f)
        }

        linePaint.apply {
            color = lineColor
            strokeWidth = 4f
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        pointPaint.apply {
            color = pointColor
            style = Paint.Style.FILL
        }

        selectedPointPaint.apply {
            color = ContextCompat.getColor(context, R.color.warning)
            style = Paint.Style.FILL
        }

        textPaint.apply {
            color = textColor
            textSize = 32f
            textAlign = Paint.Align.CENTER
        }
    }

    fun setMeasurements(measurements: List<Measurement>) {
        this.measurements = measurements.filter { it.isValid() }.sortedBy { it.ab2 }
        calculateDataBounds()
        invalidate()
    }

    private fun calculateDataBounds() {
        if (measurements.isEmpty()) {
            dataMinX = 0.1
            dataMaxX = 1000.0
            dataMinY = 0.1
            dataMaxY = 10000.0
            return
        }

        val ab2Values = measurements.map { it.ab2 }
        val resistivityValues = measurements.map { it.apparentResistivity }

        dataMinX = ab2Values.minOrNull()?.let { max(it * 0.5, 0.1) } ?: 0.1
        dataMaxX = ab2Values.maxOrNull()?.let { it * 2.0 } ?: 1000.0
        dataMinY = resistivityValues.minOrNull()?.let { max(it * 0.5, 0.1) } ?: 0.1
        dataMaxY = resistivityValues.maxOrNull()?.let { it * 2.0 } ?: 10000.0

        // Ensure 1:1 decade ratio
        val logRangeX = log10(dataMaxX) - log10(dataMinX)
        val logRangeY = log10(dataMaxY) - log10(dataMinY)
        
        if (logRangeX > logRangeY) {
            val centerLogY = (log10(dataMaxY) + log10(dataMinY)) / 2
            val halfRangeY = logRangeX / 2
            dataMinY = 10.0.pow(centerLogY - halfRangeY)
            dataMaxY = 10.0.pow(centerLogY + halfRangeY)
        } else if (logRangeY > logRangeX) {
            val centerLogX = (log10(dataMaxX) + log10(dataMinX)) / 2
            val halfRangeX = logRangeY / 2
            dataMinX = 10.0.pow(centerLogX - halfRangeX)
            dataMaxX = 10.0.pow(centerLogX + halfRangeX)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        
        val padding = 80f
        chartRect = RectF(
            padding,
            padding,
            w.toFloat() - padding,
            h.toFloat() - padding
        )
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        canvas ?: return

        if (measurements.isEmpty()) return

        drawGrid(canvas)
        drawAxes(canvas)
        drawAxisLabels(canvas)
        drawData(canvas)
    }

    private fun drawGrid(canvas: Canvas) {
        // Vertical grid lines (AB/2 axis)
        var logValue = floor(log10(dataMinX))
        while (logValue <= ceil(log10(dataMaxX))) {
            val value = 10.0.pow(logValue)
            if (value >= dataMinX && value <= dataMaxX) {
                val x = chartRect.left + (log10(value) - log10(dataMinX)) / 
                       (log10(dataMaxX) - log10(dataMinX)) * chartRect.width()
                canvas.drawLine(x.toFloat(), chartRect.top, x.toFloat(), chartRect.bottom, gridPaint)
            }
            logValue += 1.0
        }

        // Horizontal grid lines (ρa axis)
        logValue = floor(log10(dataMinY))
        while (logValue <= ceil(log10(dataMaxY))) {
            val value = 10.0.pow(logValue)
            if (value >= dataMinY && value <= dataMaxY) {
                val y = chartRect.bottom - (log10(value) - log10(dataMinY)) / 
                       (log10(dataMaxY) - log10(dataMinY)) * chartRect.height()
                canvas.drawLine(chartRect.left, y.toFloat(), chartRect.right, y.toFloat(), gridPaint)
            }
            logValue += 1.0
        }
    }

    private fun drawAxes(canvas: Canvas) {
        // X-axis
        canvas.drawLine(chartRect.left, chartRect.bottom, chartRect.right, chartRect.bottom, axisPaint)
        
        // Y-axis
        canvas.drawLine(chartRect.left, chartRect.top, chartRect.left, chartRect.bottom, axisPaint)
    }

    private fun drawAxisLabels(canvas: Canvas) {
        textPaint.textAlign = Paint.Align.CENTER
        
        // X-axis labels
        var logValue = floor(log10(dataMinX))
        while (logValue <= ceil(log10(dataMaxX))) {
            val value = 10.0.pow(logValue)
            if (value >= dataMinX && value <= dataMaxX) {
                val x = chartRect.left + (log10(value) - log10(dataMinX)) / 
                       (log10(dataMaxX) - log10(dataMinX)) * chartRect.width()
                val label = if (value >= 1) value.toInt().toString() else String.format("%.1f", value)
                canvas.drawText(label, x.toFloat(), chartRect.bottom + 40f, textPaint)
            }
            logValue += 1.0
        }

        // Y-axis labels
        textPaint.textAlign = Paint.Align.RIGHT
        logValue = floor(log10(dataMinY))
        while (logValue <= ceil(log10(dataMaxY))) {
            val value = 10.0.pow(logValue)
            if (value >= dataMinY && value <= dataMaxY) {
                val y = chartRect.bottom - (log10(value) - log10(dataMinY)) / 
                       (log10(dataMaxY) - log10(dataMinY)) * chartRect.height()
                val label = if (value >= 1) value.toInt().toString() else String.format("%.1f", value)
                canvas.drawText(label, chartRect.left - 10f, y.toFloat() + 10f, textPaint)
            }
            logValue += 1.0
        }

        // Axis titles
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText("AB/2 (m)", chartRect.centerX(), height - 20f, textPaint)
        
        canvas.save()
        canvas.rotate(-90f, 30f, chartRect.centerY())
        canvas.drawText("ρa (Ω.m)", 30f, chartRect.centerY(), textPaint)
        canvas.restore()
    }

    private fun drawData(canvas: Canvas) {
        if (measurements.size < 2) {
            // Draw only points if less than 2 measurements
            measurements.forEachIndexed { index, measurement ->
                drawPoint(canvas, measurement, index == selectedPointIndex)
            }
            return
        }

        // Draw line connecting points
        val path = Path()
        measurements.forEachIndexed { index, measurement ->
            val x = getScreenX(measurement.ab2)
            val y = getScreenY(measurement.apparentResistivity)
            
            if (index == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }
        canvas.drawPath(path, linePaint)

        // Draw points
        measurements.forEachIndexed { index, measurement ->
            drawPoint(canvas, measurement, index == selectedPointIndex)
        }
    }

    private fun drawPoint(canvas: Canvas, measurement: Measurement, isSelected: Boolean) {
        val x = getScreenX(measurement.ab2)
        val y = getScreenY(measurement.apparentResistivity)
        val paint = if (isSelected) selectedPointPaint else pointPaint
        val radius = if (isSelected) 12f else 8f
        
        canvas.drawCircle(x, y, radius, paint)
    }

    private fun getScreenX(dataX: Double): Float {
        return chartRect.left + ((log10(dataX) - log10(dataMinX)) / 
               (log10(dataMaxX) - log10(dataMinX)) * chartRect.width()).toFloat()
    }

    private fun getScreenY(dataY: Double): Float {
        return chartRect.bottom - ((log10(dataY) - log10(dataMinY)) / 
               (log10(dataMaxY) - log10(dataMinY)) * chartRect.height()).toFloat()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleGestureDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        return true
    }

    private inner class ScaleGestureListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scaleFactorX *= detector.scaleFactor
            scaleFactorY *= detector.scaleFactor
            
            // Limit scale factor
            scaleFactorX = max(0.1f, min(scaleFactorX, 10f))
            scaleFactorY = max(0.1f, min(scaleFactorY, 10f))
            
            invalidate()
            return true
        }
    }

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapUp(e: MotionEvent): Boolean {
            // Find closest point to tap
            val tapX = e.x
            val tapY = e.y
            
            var closestIndex = -1
            var minDistance = Float.MAX_VALUE
            
            measurements.forEachIndexed { index, measurement ->
                val pointX = getScreenX(measurement.ab2)
                val pointY = getScreenY(measurement.apparentResistivity)
                val distance = sqrt((tapX - pointX).pow(2) + (tapY - pointY).pow(2))
                
                if (distance < 50f && distance < minDistance) {
                    minDistance = distance
                    closestIndex = index
                }
            }
            
            if (closestIndex != -1) {
                selectedPointIndex = closestIndex
                onPointSelected?.invoke(measurements[closestIndex])
                invalidate()
                return true
            }
            
            // Clear selection if no point is close
            if (selectedPointIndex != -1) {
                selectedPointIndex = -1
                invalidate()
            }
            
            return super.onSingleTapUp(e)
        }

        fun onScrollCustom(
            e1: MotionEvent?,
            e2: MotionEvent?,
            distanceX: Float,
            distanceY: Float
        ): Boolean {
            offsetX -= distanceX
            offsetY -= distanceY
            invalidate()
            return true
        }
    }
}





