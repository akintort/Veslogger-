package com.veslogger.app.data.database

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.veslogger.app.data.dao.MeasurementDao
import com.veslogger.app.data.dao.ProjectDao
import com.veslogger.app.data.model.Measurement
import com.veslogger.app.data.model.MeasurementMode
import com.veslogger.app.data.model.Project

@Database(
    entities = [Project::class, Measurement::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class VESDatabase : RoomDatabase() {
    
    abstract fun projectDao(): ProjectDao
    abstract fun measurementDao(): MeasurementDao
    
    companion object {
        @Volatile
        private var INSTANCE: VESDatabase? = null
        
        fun getDatabase(context: Context): VESDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VESDatabase::class.java,
                    "ves_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class Converters {
    @TypeConverter
    fun fromMeasurementMode(mode: MeasurementMode): String {
        return mode.name
    }
    
    @TypeConverter
    fun toMeasurementMode(mode: String): MeasurementMode {
        return MeasurementMode.valueOf(mode)
    }
}





