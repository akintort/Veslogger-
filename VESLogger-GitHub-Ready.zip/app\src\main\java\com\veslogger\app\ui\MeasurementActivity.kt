package com.veslogger.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.veslogger.app.R
import com.veslogger.app.data.database.VESDatabase
import com.veslogger.app.data.repository.VESRepository
import com.veslogger.app.databinding.ActivityMeasurementBinding
import com.veslogger.app.ui.fragment.DataEntryFragment
import com.veslogger.app.ui.fragment.ExportFragment
import com.veslogger.app.ui.fragment.GraphFragment
import com.veslogger.app.ui.fragment.TableFragment
import com.veslogger.app.ui.viewmodel.MeasurementViewModel
import com.veslogger.app.ui.viewmodel.MeasurementViewModelFactory

class MeasurementActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMeasurementBinding
    private lateinit var viewModel: MeasurementViewModel
    
    private val dataEntryFragment = DataEntryFragment.newInstance()
    private val tableFragment = TableFragment.newInstance()
    private val graphFragment = GraphFragment.newInstance()
    private val exportFragment = ExportFragment.newInstance()
    
    private var activeFragment: Fragment = dataEntryFragment
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMeasurementBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupViewModel()
        setupUI()
        setupBottomNavigation()
        
        // Get project ID from intent
        val projectId = intent.getStringExtra(EXTRA_PROJECT_ID)
        if (projectId != null) {
            viewModel.setProjectId(projectId)
        } else {
            finish()
            return
        }
        
        // Set initial fragment
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.contentContainer, dataEntryFragment, "data_entry")
                .add(R.id.contentContainer, tableFragment, "table")
                .add(R.id.contentContainer, graphFragment, "graph")
                .add(R.id.contentContainer, exportFragment, "export")
                .hide(tableFragment)
                .hide(graphFragment)
                .hide(exportFragment)
                .commit()
        }
    }
    
    private fun setupViewModel() {
        val database = VESDatabase.getDatabase(this)
        val repository = VESRepository(database.projectDao(), database.measurementDao())
        val factory = MeasurementViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory)[MeasurementViewModel::class.java]
    }
    
    private fun setupUI() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        binding.toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
        
        // Observe project data for UI updates
        viewModel.project.observe(this) { project ->
            project?.let {
                binding.toolbar.title = "${it.name} - ${it.pointId}"
                
                // Show progress indicator for plan mode
                if (it.measurementMode == com.veslogger.app.data.model.MeasurementMode.PLAN) {
                    binding.progressIndicator.visibility = android.view.View.VISIBLE
                    binding.progressTextView.visibility = android.view.View.VISIBLE
                } else {
                    binding.progressIndicator.visibility = android.view.View.GONE
                    binding.progressTextView.visibility = android.view.View.GONE
                }
            }
        }
        
        // Observe measurement counts for progress
        viewModel.measurementCounts.observe(this) { (total, completed) ->
            if (total > 0) {
                val progress = (completed.toFloat() / total.toFloat() * 100).toInt()
                binding.progressIndicator.progress = progress
                binding.progressTextView.text = getString(R.string.current_measurement, completed + 1, total)
            }
        }
        
        // FAB click listener
        binding.fab.setOnClickListener {
            // Switch to data entry tab
            binding.bottomNavigation.selectedItemId = R.id.nav_data_entry
        }
    }
    
    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_data_entry -> {
                    showFragment(dataEntryFragment)
                    binding.fab.show()
                    true
                }
                R.id.nav_table -> {
                    showFragment(tableFragment)
                    binding.fab.hide()
                    true
                }
                R.id.nav_graph -> {
                    showFragment(graphFragment)
                    binding.fab.hide()
                    true
                }
                R.id.nav_export -> {
                    showFragment(exportFragment)
                    binding.fab.hide()
                    true
                }
                else -> false
            }
        }
    }
    
    private fun showFragment(fragment: Fragment) {
        if (fragment == activeFragment) return
        
        supportFragmentManager.beginTransaction()
            .hide(activeFragment)
            .show(fragment)
            .commit()
        
        activeFragment = fragment
    }
    
    companion object {
        const val EXTRA_PROJECT_ID = "project_id"
    }
}





